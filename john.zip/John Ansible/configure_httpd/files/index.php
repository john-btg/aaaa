<!DOCTYPE html>
<html>
    <head>
        <title><?php echo$_SERVER['SERVER_NAME']; ?></title>
    </head>
    <body>
        Nom du serveur :
        <?php
            echo$_SERVER['SERVER_NAME'];
        ?>
    </body>
</html>